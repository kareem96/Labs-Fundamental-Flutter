
enum ResultState{loading, noData, hasData, error}
