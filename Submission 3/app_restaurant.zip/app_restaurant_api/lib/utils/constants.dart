
const String baseUrl = "https://restaurant-api.dicoding.dev";
const String smallImageUrl = 'https://restaurant-api.dicoding.dev/images/small/';
const String largeImageUrl = 'https://restaurant-api.dicoding.dev/images/large/';